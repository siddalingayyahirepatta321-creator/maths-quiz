from django.urls import path
from . import views

app_name = "quiz"
urlpatterns = [
    path("", views.home, name="home"),
    path("start/", views.start_quiz, name="start"),
    path("question/<int:number>/", views.question_view, name="question"),
    path("answer/<int:number>/", views.submit_answer, name="answer"),
    path("result/", views.result, name="result"),
]
