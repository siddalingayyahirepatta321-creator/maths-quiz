from django.db import models

class Question(models.Model):
    TOPIC_CHOICES = [
        ("Percentages", "Percentages"),
        ("Profit and Loss", "Profit and Loss"),
        ("Time and Work", "Time and Work"),
        ("Number System", "Number System"),
        ("Simple Interest", "Simple Interest"),
    ]
    topic = models.CharField(max_length=40, choices=TOPIC_CHOICES)
    question_text = models.TextField()
    option_a = models.CharField(max_length=200)
    option_b = models.CharField(max_length=200)
    option_c = models.CharField(max_length=200)
    option_d = models.CharField(max_length=200)
    correct_option = models.CharField(
        max_length=1, choices=[("A","A"),("B","B"),("C","C"),("D","D")]
    )
    explanation = models.TextField()
    difficulty = models.CharField(
        max_length=10,
        choices=[("Easy","Easy"),("Medium","Medium"),("Hard","Hard")],
        default="Easy"
    )

    class Meta:
        ordering = ["topic", "id"]

    def __str__(self):
        return f"{self.topic}: {self.question_text[:60]}"

    def options(self):
        return [
            ("A", self.option_a), ("B", self.option_b),
            ("C", self.option_c), ("D", self.option_d)
        ]
