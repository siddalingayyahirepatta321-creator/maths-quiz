import random
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import Question

def home(request):
    topics = Question.objects.values_list("topic", flat=True).distinct()
    topic_counts = {
        topic: Question.objects.filter(topic=topic).count() for topic in topics
    }
    return render(request, "quiz/home.html", {"topic_counts": topic_counts})

def start_quiz(request):
    topic = request.GET.get("topic", "All")
    questions = Question.objects.all()
    if topic != "All":
        questions = questions.filter(topic=topic)
    questions = list(questions)
    random.shuffle(questions)
    questions = questions[:10]
    if not questions:
        return render(request, "quiz/empty.html", {"topic": topic})
    request.session["quiz_questions"] = [q.id for q in questions]
    request.session["quiz_answers"] = {}
    request.session["quiz_topic"] = topic
    return redirect("quiz:question", number=1)

def question_view(request, number):
    ids = request.session.get("quiz_questions", [])
    if not ids or number < 1 or number > len(ids):
        return redirect("quiz:home")
    q = Question.objects.filter(id=ids[number - 1]).first()
    if not q:
        return redirect("quiz:home")
    selected = request.session.get("quiz_answers", {}).get(str(q.id), "")
    return render(request, "quiz/question.html", {
        "question": q, "number": number, "total": len(ids),
        "selected": selected, "topic": request.session.get("quiz_topic", "All")
    })

@require_POST
def submit_answer(request, number):
    ids = request.session.get("quiz_questions", [])
    if not ids or number < 1 or number > len(ids):
        return redirect("quiz:home")
    q = Question.objects.filter(id=ids[number - 1]).first()
    if not q:
        return redirect("quiz:home")
    answer = request.POST.get("answer", "")
    if answer not in ["A", "B", "C", "D"]:
        return redirect("quiz:question", number=number)
    answers = request.session.get("quiz_answers", {})
    answers[str(q.id)] = answer
    request.session["quiz_answers"] = answers
    request.session.modified = True
    if number < len(ids):
        return redirect("quiz:question", number=number + 1)
    return redirect("quiz:result")

def result(request):
    ids = request.session.get("quiz_questions", [])
    answers = request.session.get("quiz_answers", {})
    questions = Question.objects.filter(id__in=ids)
    details = []
    score = 0
    for qid in ids:
        q = next((item for item in questions if item.id == qid), None)
        if not q:
            continue
        chosen = answers.get(str(q.id), "")
        correct = chosen == q.correct_option
        if correct:
            score += 1
        details.append({
            "question": q, "chosen": chosen, "correct": correct,
            "chosen_text": dict(q.options()).get(chosen, ""),
            "correct_text": dict(q.options()).get(q.correct_option, ""),
        })
    total = len(details)
    percentage = round((score / total) * 100) if total else 0
    request.session.pop("quiz_questions", None)
    request.session.pop("quiz_answers", None)
    request.session.pop("quiz_topic", None)
    return render(request, "quiz/result.html", {
        "details": details, "score": score, "total": total,
        "percentage": percentage, "wrong": total - score
    })
