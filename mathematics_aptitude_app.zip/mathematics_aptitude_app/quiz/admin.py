from django.contrib import admin
from .models import Question

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ("question_text", "topic", "difficulty", "correct_option")
    list_filter = ("topic", "difficulty")
    search_fields = ("question_text",)
