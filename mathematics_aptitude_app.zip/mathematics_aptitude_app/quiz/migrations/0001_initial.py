from django.db import migrations, models

class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="Question",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("topic", models.CharField(choices=[("Percentages","Percentages"),("Profit and Loss","Profit and Loss"),("Time and Work","Time and Work"),("Number System","Number System"),("Simple Interest","Simple Interest")], max_length=40)),
                ("question_text", models.TextField()),
                ("option_a", models.CharField(max_length=200)),
                ("option_b", models.CharField(max_length=200)),
                ("option_c", models.CharField(max_length=200)),
                ("option_d", models.CharField(max_length=200)),
                ("correct_option", models.CharField(choices=[("A","A"),("B","B"),("C","C"),("D","D")], max_length=1)),
                ("explanation", models.TextField()),
                ("difficulty", models.CharField(choices=[("Easy","Easy"),("Medium","Medium"),("Hard","Hard")], default="Easy", max_length=10)),
            ],
            options={"ordering":["topic","id"]},
        ),
    ]
