from django.core.management.base import BaseCommand
from quiz.models import Question

DATA = [
("Percentages","What is 20% of 250?","40","45","50","55","C","20/100 × 250 = 50.","Easy"),
("Percentages","A number increases from 80 to 100. What is the percentage increase?","20%","25%","่น30%","ใช้ 35%","B","Increase = 20. Percentage increase = (20/80) × 100 = 25%.","Easy"),
("Percentages","If 40% of a number is 120, what is the number?","240","280","300","320","C","Number = 120 ÷ 0.40 = 300.","Medium"),
("Profit and Loss","An item bought for ₹500 is sold for ₹600. Find the profit percentage.","10%","15%","20%","25%","C","Profit = 600 − 500 = ₹100. Profit percentage = 100/500 × 100 = 20%.","Easy"),
("Profit and Loss","A product is sold for ₹450 at a loss of 10%. Find its cost price.","₹475","₹490","₹500","₹525","C","Selling price is 90% of cost price. Cost price = 450/0.9 = ₹500.","Medium"),
("Profit and Loss","A shopkeeper marks an item at ₹800 and gives a 10% discount. What is the selling price?","₹700","₹710","₹720","₹740","C","Discount = 10% of 800 = ₹80. Selling price = ₹720.","Easy"),
("Time and Work","A can complete a job in 10 days. What part of the job does A complete in one day?","1/5","1/10","1/15","1/20","B","One-day work = 1 divided by 10 = 1/10.","Easy"),
("Time and Work","A completes a job in 6 days and B in 3 days. How long together?","1 day","2 days","3 days","4 days","B","Combined daily work = 1/6 + 1/3 = 1/2. Time = 2 days.","Medium"),
("Time and Work","If 5 workers finish a task in 12 days, how many days will 10 workers take at the same rate?","4","5","6","8","C","Workers and days are inversely proportional: 5 × 12 / 10 = 6 days.","Easy"),
("Number System","What is the smallest prime number?","0","1","2","3","C","2 is the smallest prime number; it has exactly two positive factors.","Easy"),
("Number System","What is the HCF of 24 and 36?","6","8","12","18","C","The greatest number that divides both 24 and 36 is 12.","Easy"),
("Number System","What is the remainder when 157 is divided by 10?","5","6","7","8","C","157 = 10 × 15 + 7, so the remainder is 7.","Easy"),
("Simple Interest","Find simple interest on ₹1000 at 5% per year for 2 years.","₹50","₹100","₹150","₹200","B","SI = (P × R × T)/100 = (1000 × 5 × 2)/100 = ₹100.","Easy"),
("Simple Interest","At 8% simple interest, how much interest is earned on ₹2500 in 3 years?","₹500","₹550","₹600","₹650","C","SI = (2500 × 8 × 3)/100 = ₹600.","Medium"),
("Simple Interest","A sum earns ₹240 simple interest in 2 years at 6% per annum. Find the principal.","₹1800","₹2000","₹2200","₹2400","B","P = (SI × 100)/(R × T) = (240 × 100)/(6 × 2) = ₹2000.","Medium"),
]

class Command(BaseCommand):
    help = "Load sample mathematics aptitude questions"

    def handle(self, *args, **options):
        created = 0
        for row in DATA:
            topic, question, a, b, c, d, correct, explanation, difficulty = row
            _, was_created = Question.objects.get_or_create(
                topic=topic, question_text=question,
                defaults={
                    "option_a": a, "option_b": b, "option_c": c, "option_d": d,
                    "correct_option": correct, "explanation": explanation,
                    "difficulty": difficulty,
                }
            )
            created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f"Added {created} sample questions."))
